This 'busy-buy' project, 'my-pod' is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

# Since React.js docs have been migrated to Next.js now, hence I have given a try to implement using Next.js

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

# Imp !!!!
The browser events are not working properly in recen versions of Chrome and Edge; please use Firefox (  as I have used the same ) 

# Thought process

The design has been kept minimilastic, emphasizing on CRUD operations only in React.

The Redux Toolkit has been integrated


Open [http://localhost:8080](http://localhost:8080) with your browser to see the result.

# github: 

