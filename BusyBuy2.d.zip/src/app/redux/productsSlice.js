import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  loading: false,
  products: [],
  cart: [],
  orders: [],
  maxCartValue: 0,
  cartId: null,
  orderId: null
}


export const productsSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    setProductsState: (state, action) => {
      state[Object.keys(action.payload)[0]] = Object.values(action.payload)[0]
    },
    setAll: (state, action) => {
      let max = 0
      for (const item of action.payload) {
        if (item.price > max) max = item.price
      }
      
      state.products = action.payload
      state.maxCartValue = max
    },
  }
})

export const productsReducer = productsSlice.reducer

export const { setProductsState, setAll } = productsSlice.actions

export const productsSelector = state => state.productsReducer
