import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    users: [],
    signedInUser: {

    }
}

export const authSlice = createSlice({
    name: 'auth',
    initialState: initialState,
    reducers: {
        setUser: (state, action) => {
            state.signedInUser = action.payload
        }
    },
})

export const authReducer = authSlice.reducer

export const {setUser} = authSlice.actions

export const authSelector = state => state.authReducer
